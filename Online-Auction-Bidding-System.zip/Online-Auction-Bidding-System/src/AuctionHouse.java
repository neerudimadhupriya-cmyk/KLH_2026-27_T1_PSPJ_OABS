import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class AuctionHouse implements Reportable {
    private final Map<String, Bidder> bidders = new LinkedHashMap<>();
    private final Map<String, Lot> lots = new LinkedHashMap<>();

    public void registerBidder(String id, String name) throws AuctionException {
        if (id.isBlank() || name.isBlank()) throw new AuctionException("ID and name cannot be empty.");
        if (bidders.containsKey(id.toUpperCase())) throw new AuctionException("Bidder ID already exists.");
        bidders.put(id.toUpperCase(), new Bidder(id.toUpperCase(), name));
    }

    public void addLot(String id, String name, double startingPrice,
                       double increment, LocalDateTime closingTime) throws AuctionException {
        if (id.isBlank() || name.isBlank()) throw new AuctionException("Lot ID and item name cannot be empty.");
        if (lots.containsKey(id.toUpperCase())) throw new AuctionException("Lot ID already exists.");
        if (startingPrice <= 0 || increment <= 0) throw new AuctionException("Prices must be greater than zero.");
        if (!closingTime.isAfter(LocalDateTime.now())) throw new AuctionException("Closing time must be in the future.");
        lots.put(id.toUpperCase(), new Lot(id.toUpperCase(), name, startingPrice, increment, closingTime));
    }

    public void placeBid(String lotId, String bidderId, double maximum) throws AuctionException {
        Lot lot = lots.get(lotId.toUpperCase());
        Bidder bidder = bidders.get(bidderId.toUpperCase());
        if (lot == null) throw new AuctionException("Lot not found.");
        if (bidder == null) throw new AuctionException("Bidder not found.");
        lot.placeProxyBid(bidder, maximum);
        saveBidToFile(lot.getBidHistory().get(lot.getBidHistory().size() - 1));
    }

    private void saveBidToFile(Bid bid) {
        try {
            Path directory = Paths.get("data");
            Files.createDirectories(directory);
            Path file = directory.resolve("bid-history.csv");
            if (!Files.exists(file)) {
                Files.writeString(file, "Lot ID,Bidder ID,Maximum Bid,Time" + System.lineSeparator(),
                        StandardOpenOption.CREATE);
            }
            Files.writeString(file, bid + System.lineSeparator(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Warning: Could not save bid history: " + e.getMessage());
        }
    }

    public void closeDueAuctions() {
        lots.values().stream()
                .filter(lot -> !lot.isOpen())
                .forEach(Lot::close);
    }

    public void closeAuction(String lotId) throws AuctionException {
        Lot lot = lots.get(lotId.toUpperCase());
        if (lot == null) throw new AuctionException("Lot not found.");
        lot.close();
    }

    public void displayLots() {
        if (lots.isEmpty()) {
            System.out.println("No auction lots available.");
            return;
        }
        lots.values().forEach(lot -> System.out.println(lot.summary()));
    }

    public void displayBidders() {
        if (bidders.isEmpty()) {
            System.out.println("No registered bidders.");
            return;
        }
        bidders.values().forEach(System.out::println);
    }

    @Override
    public void generateReport() throws IOException {
        Path directory = Paths.get("reports");
        Files.createDirectories(directory);
        Path report = directory.resolve("auction-sales-report.txt");

        List<String> lines = new ArrayList<>();
        lines.add("ONLINE AUCTION - SALES AND SETTLEMENT REPORT");
        lines.add("Generated: " + LocalDateTime.now());
        lines.add("==================================================");

        for (Lot lot : lots.values()) {
            lines.add(lot.summary());
            if (lot.isClosed()) {
                if (lot.getHighestBidder() == null) {
                    lines.add("Result: UNSOLD");
                } else {
                    lines.add(String.format("Result: SOLD to %s (%s) for %.2f",
                            lot.getHighestBidder().getName(),
                            lot.getHighestBidder().getBidderId(), lot.getCurrentPrice()));
                }
            }
            lines.add("--------------------------------------------------");
        }

        long soldCount = lots.values().stream()
                .filter(l -> l.isClosed() && l.getHighestBidder() != null).count();
        long unsoldCount = lots.values().stream()
                .filter(l -> l.isClosed() && l.getHighestBidder() == null).count();
        double totalSales = lots.values().stream()
                .filter(l -> l.isClosed() && l.getHighestBidder() != null)
                .mapToDouble(Lot::getCurrentPrice).sum();

        lines.add("Total registered bidders: " + bidders.size());
        lines.add("Sold lots: " + soldCount);
        lines.add("Unsold lots: " + unsoldCount);
        lines.add(String.format("Total sales value: %.2f", totalSales));

        Files.write(report, lines);
        System.out.println("Report generated: " + report.toAbsolutePath());
    }

    public void displayBidHistory(String lotId) throws AuctionException {
        Lot lot = lots.get(lotId.toUpperCase());
        if (lot == null) throw new AuctionException("Lot not found.");
        if (lot.getBidHistory().isEmpty()) {
            System.out.println("No bids for this lot.");
            return;
        }
        lot.getBidHistory().forEach(System.out::println);
    }
}
