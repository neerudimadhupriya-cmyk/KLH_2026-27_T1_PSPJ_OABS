import java.time.LocalDateTime;

public record Bid(String lotId, String bidderId, double amount, LocalDateTime time) {
    @Override
    public String toString() {
        return lotId + "," + bidderId + "," + amount + "," + time;
    }
}
