public interface BidValidator {
    void validate(Lot lot, Bidder bidder, double maximumAmount) throws AuctionException;
}
