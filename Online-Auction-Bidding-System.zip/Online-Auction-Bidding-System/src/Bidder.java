import java.util.Objects;

public class Bidder {
    private final String bidderId;
    private final String name;

    public Bidder(String bidderId, String name) {
        this.bidderId = bidderId;
        this.name = name;
    }

    public String getBidderId() { return bidderId; }
    public String getName() { return name; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Bidder)) return false;
        Bidder other = (Bidder) obj;
        return bidderId.equalsIgnoreCase(other.bidderId);
    }

    @Override
    public int hashCode() { return Objects.hash(bidderId.toLowerCase()); }

    @Override
    public String toString() { return bidderId + " - " + name; }
}
