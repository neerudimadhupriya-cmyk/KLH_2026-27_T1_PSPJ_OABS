public class DefaultBidValidator implements BidValidator {
    @Override
    public void validate(Lot lot, Bidder bidder, double maximumAmount)
            throws AuctionException {
        if (bidder == null) {
            throw new AuctionException("Bidder not found. Register the bidder first.");
        }
        if (!lot.isOpen()) {
            throw new AuctionException("This auction is closed.");
        }
        if (maximumAmount <= 0) {
            throw new AuctionException("Bid amount must be greater than zero.");
        }
        if (maximumAmount < lot.getStartingPrice()) {
            throw new AuctionException("Your maximum must be at least the starting price.");
        }
        Double previous = lot.getProxyMaximum(bidder);
        if (previous != null && maximumAmount <= previous) {
            throw new AuctionException("Your new maximum must be higher than your previous maximum.");
        }
        if (maximumAmount < lot.getCurrentPrice() + lot.getMinimumIncrement()
                && previous == null) {
            throw new AuctionException("Your maximum must be at least the current price plus the minimum increment.");
        }
    }
}
