import java.time.LocalDateTime;
import java.util.*;

public class Lot {
    private final String lotId;
    private final String itemName;
    private final double startingPrice;
    private final double minimumIncrement;
    private final LocalDateTime closingTime;
    private final Map<Bidder, Double> proxyMaximums = new LinkedHashMap<>();
    private final List<Bid> bidHistory = new ArrayList<>();
    private double currentPrice;
    private Bidder highestBidder;
    private boolean closed;

    public Lot(String lotId, String itemName, double startingPrice,
               double minimumIncrement, LocalDateTime closingTime) {
        this.lotId = lotId;
        this.itemName = itemName;
        this.startingPrice = startingPrice;
        this.minimumIncrement = minimumIncrement;
        this.closingTime = closingTime;
        this.currentPrice = startingPrice;
        this.closed = !closingTime.isAfter(LocalDateTime.now());
    }

    public void placeProxyBid(Bidder bidder, double maximum) throws AuctionException {
        new DefaultBidValidator().validate(this, bidder, maximum);
        proxyMaximums.put(bidder, maximum);
        recalculateWinner();
        bidHistory.add(new Bid(lotId, bidder.getBidderId(), maximum, LocalDateTime.now()));
    }

    private void recalculateWinner() {
        List<Map.Entry<Bidder, Double>> ranking = new ArrayList<>(proxyMaximums.entrySet());
        ranking.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        if (ranking.isEmpty()) {
            highestBidder = null;
            currentPrice = startingPrice;
            return;
        }

        highestBidder = ranking.get(0).getKey();
        double winningMaximum = ranking.get(0).getValue();

        if (ranking.size() == 1) {
            currentPrice = startingPrice;
        } else {
            double secondMaximum = ranking.get(1).getValue();
            currentPrice = Math.min(winningMaximum,
                    Math.max(startingPrice, secondMaximum + minimumIncrement));
        }
    }

    public void close() { closed = true; }
    public boolean isOpen() {
        return !closed && closingTime.isAfter(LocalDateTime.now());
    }
    public boolean isClosed() { return !isOpen(); }
    public String getLotId() { return lotId; }
    public String getItemName() { return itemName; }
    public double getStartingPrice() { return startingPrice; }
    public double getMinimumIncrement() { return minimumIncrement; }
    public LocalDateTime getClosingTime() { return closingTime; }
    public double getCurrentPrice() { return currentPrice; }
    public Bidder getHighestBidder() { return highestBidder; }
    public List<Bid> getBidHistory() { return Collections.unmodifiableList(bidHistory); }
    public Double getProxyMaximum(Bidder bidder) { return proxyMaximums.get(bidder); }

    public String getStatus() { return isOpen() ? "OPEN" : "CLOSED"; }

    public String summary() {
        String winner = highestBidder == null ? "No bids" : highestBidder.getName();
        return String.format("%s | %s | Starting: %.2f | Current: %.2f | %s | Winner: %s",
                lotId, itemName, startingPrice, currentPrice, getStatus(), winner);
    }
}
