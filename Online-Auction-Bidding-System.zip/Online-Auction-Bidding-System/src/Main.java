import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final AuctionHouse auctionHouse = new AuctionHouse();

    public static void main(String[] args) {
        System.out.println("======================================");
        System.out.println("     ONLINE AUCTION & BIDDING SYSTEM");
        System.out.println("======================================");

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1" -> registerBidder();
                    case "2" -> createLot();
                    case "3" -> auctionHouse.displayLots();
                    case "4" -> auctionHouse.displayBidders();
                    case "5" -> placeBid();
                    case "6" -> closeAuction();
                    case "7" -> auctionHouse.closeDueAuctions();
                    case "8" -> showBidHistory();
                    case "9" -> auctionHouse.generateReport();
                    case "0" -> {
                        running = false;
                        System.out.println("Thank you for using the Auction System!");
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (AuctionException | java.io.IOException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date/time. Use format: yyyy-MM-ddTHH:mm");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\\n--------------- MENU ---------------");
        System.out.println("1. Register bidder");
        System.out.println("2. Create auction lot");
        System.out.println("3. View auction lots");
        System.out.println("4. View registered bidders");
        System.out.println("5. Place bid / Set proxy maximum");
        System.out.println("6. Close an auction");
        System.out.println("7. Close auctions whose time has expired");
        System.out.println("8. View bid history");
        System.out.println("9. Generate sales and settlement report");
        System.out.println("0. Exit");
        System.out.println("------------------------------------");
    }

    private static void registerBidder() throws AuctionException {
        System.out.print("Enter bidder ID: ");
        String id = scanner.nextLine().trim();
        System.out.print("Enter bidder name: ");
        String name = scanner.nextLine().trim();
        auctionHouse.registerBidder(id, name);
        System.out.println("Bidder registered successfully.");
    }

    private static void createLot() throws AuctionException {
        System.out.print("Enter lot ID: ");
        String id = scanner.nextLine().trim();
        System.out.print("Enter item name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Enter starting price: ");
        double price = Double.parseDouble(scanner.nextLine().trim());
        System.out.print("Enter minimum increment: ");
        double increment = Double.parseDouble(scanner.nextLine().trim());
        System.out.print("Enter closing date/time (yyyy-MM-ddTHH:mm): ");
        LocalDateTime closing = LocalDateTime.parse(scanner.nextLine().trim());
        auctionHouse.addLot(id, name, price, increment, closing);
        System.out.println("Auction lot created successfully.");
    }

    private static void placeBid() throws AuctionException {
        System.out.print("Enter lot ID: ");
        String lotId = scanner.nextLine().trim();
        System.out.print("Enter bidder ID: ");
        String bidderId = scanner.nextLine().trim();
        System.out.print("Enter your maximum bid amount: ");
        double maximum = Double.parseDouble(scanner.nextLine().trim());
        auctionHouse.placeBid(lotId, bidderId, maximum);
        System.out.println("Proxy maximum recorded. The system has recalculated the current winner and price.");
    }

    private static void closeAuction() throws AuctionException {
        System.out.print("Enter lot ID to close: ");
        auctionHouse.closeAuction(scanner.nextLine().trim());
        System.out.println("Auction closed.");
    }

    private static void showBidHistory() throws AuctionException {
        System.out.print("Enter lot ID: ");
        auctionHouse.displayBidHistory(scanner.nextLine().trim());
    }
}
